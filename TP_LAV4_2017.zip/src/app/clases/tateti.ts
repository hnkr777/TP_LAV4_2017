
import { Juego } from './juego'
import { Jugador } from './jugador'
import { TatetiComponent } from "../componentes/tateti/tateti.component";
import { setInterval } from 'timers';
import { JuegoServiceService } from "../servicios/juego-service.service";
import { ArchivosJuegosServiceService } from "../servicios/archivos-juegos-service.service";

export class Tateti extends Juego {
    gana: boolean;
    empata: boolean;
    pierde: boolean;

    private tmp: string = "";

    mat: Array<number> = [0, 0, 0, 0, 0, 0, 0, 0, 0];

    contador: number;
    public partidaTerminada: number;

    private jugada = ["Perdió", "Empató", "Ganó"];

    jugador : number = 0;
    puntosMaquina: number;
    puntosJugador: number;
    maquina : number = 0;
    
    constructor(public servicioJuego: JuegoServiceService) {
        super('Tateti', "Ta Te Ti");
        this.empata = false;
        this.gana = false;
        this.pierde = false;
        this.nuevaPartida();
    }

    public nuevaPartida() {
        this.contador = 0;
        this.mat = [0, 0, 0, 0, 0, 0, 0, 0, 0];
        this.partidaTerminada = 0;
        this.tmp = '';
        
        if(document.getElementsByClassName('boton').item(1)!==null)
        for (let i = 0; i < 9; i++) {
            document.getElementsByClassName('boton').item(i).classList.remove('selected');
            document.getElementsByClassName('boton').item(i).classList.remove('cruz');
            document.getElementsByClassName('boton').item(i).classList.remove('circulo');
        }
        
    }

    public guardarJugada(): boolean {
        this.datos = JSON.stringify({
            gano: this.gana,
            empato: this.empata,
            perdio: this.pierde
        });
        
        this.servicioJuego.guardarPartida('guardarjugada', this);
        console.info('Jugada NO guardada.');
        return true;
    }

    public jugar(eleccion: number): string {
        if(this.partidaTerminada == 1) {
            this.partidaTerminada = -1;
            return 'Partida terminada.';
        } else if(this.partidaTerminada == -1) {
            this.nuevaPartida();
            return 'Nueva partida, juega con cruces';
        }

        if(this.mat[eleccion-1] !=0 ) {
            return 'Celda ocupada, elija otra.';
        }
        
        this.contador++;
        
        console.info('celda: '+ eleccion);
        document.getElementsByClassName('boton').item(eleccion-1).classList.add('selected');
        document.getElementsByClassName('boton').item(eleccion-1).classList.add('cruz');
        this.mat[eleccion-1] = 1;
        this.jugador = eleccion;

        if(this.comprobar()!= -2)
            return this.tmp;
        
        this.jugarMaquina();
        this.comprobar();

        return this.tmp;
    }

    private comprobar(): number {
        let ganador: number = this.verificar();
        
        if(this.contador==9 || ganador!=0) {
            this.gana = ganador == 1;
            this.pierde = ganador == -1;
            this.empata = ganador == 0;
            this.guardarJugada();
            this.partidaTerminada = 1;
            this.tmp = this.jugada[ganador+1];
            
            console.log('Partida terminada, el jugador '+ this.jugada[ganador+1]);
            return ganador;
        }
        return -2;
    }

    public jugarMaquina() {
        let m: number;
        let c = this.mat;

        do {
            m =  Math.floor((Math.random() * 9) + 1);

        } while(c[m-1] != 0);
        this.maquina = m;

        console.info('celda maquina: '+ m);
        document.getElementsByClassName('boton').item(m-1).classList.add('selected');
        document.getElementsByClassName('boton').item(m-1).classList.add('circulo');
        this.mat[m-1] = -1;
    }


    public verificar(): number {
        let m = this.mat;
        let ganador: number = 0;

        if(m[0] == m[3] && m[3] == m[6] && m[6] != 0) {
            ganador = m[0];
        } else if(m[1] == m[4] && m[4] == m[7] && m[7] != 0) {
            ganador = m[1];
        } else if(m[2] == m[5] && m[5] == m[8] && m[8] != 0) {
            ganador = m[2];
        }

        else if(m[0] == m[1] && m[1] == m[2] && m[2] != 0) {
            ganador = m[0];
        } else if(m[3] == m[4] && m[4] == m[5] && m[5] != 0) {
            ganador = m[3];
        } else if(m[6] == m[7] && m[7] == m[8] && m[8] != 0) {
            ganador = m[6];
        }

        else if(m[0] == m[4] && m[4] == m[8] && m[8] != 0) {
            ganador = m[0];
        } else if(m[2] == m[4] && m[4] == m[6] && m[6] != 0) {
            ganador = m[2];
        }

        return ganador;
    }

}
