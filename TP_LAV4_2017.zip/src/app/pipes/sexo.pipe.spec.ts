import { SexoPipe } from './sexo.pipe';

describe('SexoPipe', () => {
  it('create an instance', () => {
    const pipe = new SexoPipe();
    expect(pipe).toBeTruthy();
  });
});
