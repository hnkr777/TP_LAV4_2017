import { TipoJuegoPipe } from './tipo-juego.pipe';

describe('TipoJuegoPipe', () => {
  it('create an instance', () => {
    const pipe = new TipoJuegoPipe();
    expect(pipe).toBeTruthy();
  });
});
